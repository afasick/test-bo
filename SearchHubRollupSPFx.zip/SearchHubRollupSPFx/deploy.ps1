$config = Get-Content -Path "$($PSScriptRoot)/deploy_config.json" | ConvertFrom-Json;

function GetAccessToken {
    param()

    Write-Host "Checking for AzureAD module..."
    if (!$CredPrompt){$CredPrompt = 'Auto'}
    $AadModule = Get-Module -Name "AzureAD" -ListAvailable
    if ($AadModule -eq $null) {$AadModule = Get-Module -Name "AzureADPreview" -ListAvailable}
    if ($AadModule -eq $null) {write-host "AzureAD Powershell module is not installed. The module can be installed by running 'Install-Module AzureAD' or 'Install-Module AzureADPreview' from an elevated PowerShell prompt. Stopping." -f Yellow;exit}
    if ($AadModule.count -gt 1) {
        $Latest_Version = ($AadModule | select version | Sort-Object)[-1]
        $aadModule      = $AadModule | ? { $_.version -eq $Latest_Version.version }
        $adal           = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms      = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
        }
    else {
        $adal           = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.dll"
        $adalforms      = Join-Path $AadModule.ModuleBase "Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll"
        }
    [System.Reflection.Assembly]::LoadFrom($adal) | Out-Null
    [System.Reflection.Assembly]::LoadFrom($adalforms) | Out-Null

    $userName = $config.SPODeploymentUser
    $securePassword = $config.SPODeploymentUserPassword
    $resource = "https://golubcapital.sharepoint.com"
    $authString = "https://login.microsoftonline.com/golubcapital.onmicrosoft.com"
    $clientId = "d868769a-4650-4bb8-b0f5-e386706fd1d9";
    $authContext = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext" -ArgumentList $authString, $false
    $AADcredential = New-Object "Microsoft.IdentityModel.Clients.ActiveDirectory.UserPasswordCredential"  -argumentlist $username, $securePassword
    $authResult = [Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContextIntegratedAuthExtensions]::AcquireTokenAsync($authContext, $resource, $clientId, $AADcredential).result;

    return $authResult.AccessToken;
}

$target = $config.EnvironmentTarget;
ForEach ($siteUrl in $config.Urls.$target) {
    $token = GetAccessToken;

    Connect-PnPOnline -Url $siteUrl -AccessToken $token
    $connection = Get-PnPConnection
    $context = $connection.CloneContext($siteUrl);
    $connection.Context = $context
    Set-PnPContext -Context  $context
    $web = Get-PnPWeb

    Add-PnPApp -Path "./search-hub-rollup.sppkg" -Scope Site -Publish -Overwrite;
}